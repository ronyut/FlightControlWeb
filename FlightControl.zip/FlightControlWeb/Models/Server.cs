/* This class represents an external server.
 * 
 * Author: Rony Utesvky.
 * Date: May 28, 2020
 */

using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FlightControlWeb.Models
{
    public class Server
    {
        [Required]
        [JsonProperty("ServerId")]
        public string key { get; set; }
        [Required]
        [JsonProperty("ServerURL")]
        public string url { get; set; }

        /*
         * Ctor
         */
        public Server(string key, string url)
        {
            this.key = key;
            this.url = url;
        }

        /*
         * Check if this is the same server as host
         */
        public void AssertServer(string host) {
            // don't request from self
            if (this.url == host || this.url.Contains(host + "/"))
            {
                throw new Exception("Cannot refernce to self");
            }
        }
    }
}