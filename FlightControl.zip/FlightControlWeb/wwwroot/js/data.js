/*
 * script for data in project - containt global variables and functions
 * for handling data.
 * written by Yehonatan Sofri in May 2020.
 */

let GET_FLIGHT_PLAN_URI = "api/FlightPlan/";
let GET_FLIGHT_URI = "api/Flights?relative_to=";
let DELETE_FLIGHT_URI = "api/Flights/";
let POST_FLIGHT_PLAN_URI = "api/FlightPlan";
let BLUE_ICON = "img/planeIcons/plane-blue.png";
let RED_ICON = "img/planeIcons/plane-red.png"
let ISO_REGEX_MODIFIER = /[^.]*/m;
let ISO_REGEX_FINDER = /[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}Z/m;
let DEFAULT_INPUT_MESSAGE = "Drop json";
let INTERVAL = 250;
let ANIMATION_DURATION = 750;
let MIN_ID_LENGTH = 6;
let MAX_ID_LENGTH = 10;
let ALERT_TEMPLATE = "<div class=\"alert alert-warning alert-dismissible fade"
                     + " show\" role=\"alert\"><strong>Error - </strong> <span"
                     + " id=\"error-message\"></span><button type=\"button\""
                     + " class=\"close\" data-dismiss=\"alert\" aria-label=\""
                     + "Close\"><span aria-hidden=\"true\">&times;</span></"
                     + "button></div>"
let LI_INTERNAL_PREFIX = "<li id=\"template\" type=\"button\" class=\""
                         + "list-group-item list-group-item-action\" "
                         + "data-toggle=\"collapse\"><button type=\"button"
                         + "\" class=\"close close-flight\"> <span>&times;"
                         + "</span></button>";
let LI_EXTERNAL_PREFIX = "<li id=\"template\" type=\"button\" class=\""
                         + "list-group-item list-group-item-action\"data-toggle"
                         + "=\"collapse\">";
let LI_INFIX = ", &nbsp; <strong>";
let LI_POSTFIX = "</strong></li>";
let HEADERS = {
  "Content-Type": 'application/json'
};
let internalFlightsNumber = 0;
let externalFlightsNumber = 0;
let currentFlight = null;
let map;
let mapIsSet = false;

// json of all icons on map, where key is the flight id.
let markers = {};


// return true if json miss at least one required field of flightPlan object.
function flightPlanMissFields(json) {
  if (!Object.prototype.hasOwnProperty.call(json, "passengers")) {
      return true;
  }
  if (!Object.prototype.hasOwnProperty.call(json, "company_name")) {
      return true;
  }
  if (!Object.prototype.hasOwnProperty.call(json, "initial_location")) {
      return true;
  }
  if (!Object.prototype.hasOwnProperty.call(json, "segments")) {
      return true;
  }
  return false;
}

// return true if json miss at least one required field of flight object.
function flightMissFields(json) {
  if (!Object.prototype.hasOwnProperty.call(json, "passengers")) {
      return true;
  }
  if (!Object.prototype.hasOwnProperty.call(json, "longitude")) {
      return true;
  }
  if (!Object.prototype.hasOwnProperty.call(json, "latitude")) {
      return true;
  }
  if (!Object.prototype.hasOwnProperty.call(json, "flight_id")) {
      return true;
  }
  if (!Object.prototype.hasOwnProperty.call(json, "date_time")) {
      return true;
  }
  if (!Object.prototype.hasOwnProperty.call(json, "company_name")) {
      return true;
  }
  if (!Object.prototype.hasOwnProperty.call(json, "is_external")) {
      return true;
  }
   return false;
}

function validateIsExternal(input) {
  return typeof input === "boolean";
}

function validateFlightId(input) {
  if (input.length <= MAX_ID_LENGTH && input.length >= MIN_ID_LENGTH) {
    return (typeof input === 'string');
  }

  return false;
}

function validatePassengers(passengers) {
  let varType = typeof(passengers)
  let answer = false;

  if (varType === 'number') {
    answer = Number.isInteger(passengers);
  } else if (varType === 'string') {
    let n = Math.floor(Number(passengers));
    answer = n !== Infinity && String(n) === passengers && n >= 0;
  }

  return answer;
}

function validateCompanyName(name) {
  return typeof name === 'string';
}

function validateLatitude(input) {
  return ((input <= 90) && (input >= -90));
}

function validateLongitude(input) {
  return ((input <= 180) && (input >= -180));
}

function validateDateTime(input) {
  let first_match = ISO_REGEX_FINDER.exec(input);

  return (first_match != null && (first_match[0] === input));
}

function validateInitialLocation(initial_location) {
  let answer = true;

  if (!(Object.prototype.hasOwnProperty.call(initial_location, 'latitude')
        && Object.prototype.hasOwnProperty.call(initial_location, 'longitude')
        && Object.prototype.hasOwnProperty.call(initial_location, 'date_time'))) {
    return false;
  }

  answer &= validateLatitude(initial_location.latitude);
  answer &= validateLongitude(initial_location.longitude);
  answer &= validateDateTime(initial_location.date_time);

  return answer;
}

function validateSegments(segments) {
  let answer = true;

  if (!Array.isArray(segments)) {
    return false;
  }

  for (let item of segments) {
    answer &= validateLongitude(item.longitude);
    answer &= validateLatitude(item.latitude);
  }

  return answer;
}

// make sure flight plan json is valid.
function validateFlightPlan(json) {
  if (!json) return false;

  let allIsGood = true;

  allIsGood &= validatePassengers(json.passengers);
  allIsGood &= validateCompanyName(json.company_name);
  allIsGood &= validateInitialLocation(json.initial_location);
  allIsGood &= validateSegments(json.segments);

  return allIsGood;
}

// validate json of flightplan uploaded by user.
function validateFlightPlanInput(fpString) {
  try {
    var data = JSON.parse(fpString);
    
    // check it's a json file
    if (flightPlanMissFields(data)) {
      return false;
    }

    return validateFlightPlan(data);
  }
  catch(e) {
    return false;
  }
}

// make sure flight object has valid data.
function validateFlight(flight) {
  let allIsGood = true;

  if (flightMissFields(flight)) return false;

  allIsGood &= validateLongitude(flight.longitude);
  allIsGood &= validateLatitude(flight.latitude);
  allIsGood &= validatePassengers(flight.passengers);
  allIsGood &= validateCompanyName(flight.company_name);
  allIsGood &= validateDateTime(flight.date_time);
  allIsGood &= validateIsExternal(flight.is_external);
  allIsGood &= validateFlightId(flight.flight_id);

  return allIsGood;
}

// return time in UTC without milliseconds.
function getCurrentTimeISO() {
  let time = new Date();

  return ISO_REGEX_MODIFIER.exec(time.toISOString()) + 'Z';
}

// convert to a more readable time string.
function convertISOToTimeString(iso) {
  if (iso == null) {
    iso = getCurrentTimeISO();
  }

  let time = new Date(iso);

  let day = (time.getDate()).toString();
  let month = (time.getMonth() + 1).toString();
  let year = (time.getFullYear()).toString();
  let hours = (time.getHours()).toString();
   let minutes = (time.getMinutes()).toString();

   if (minutes.length == 1) {
      minutes = "0" + minutes;
   }

  return day + '/' + month + '/' + year + ' ' + hours + ':' + minutes;
}

// get an array of flights and flight id, returns requested flight
function getFlightFromArray(flights, flightId) {
  if (!(flights && flightId)) return false;

  if (flights.constructor !== Array) {
    flights = [flights];
  }

  for (let flight of flights) {
    let tmp_id = flight.flight_id;

    if (tmp_id === flightId) return flight;
  }
  return false;
}

//get an array of flights and return a json with flight ids as keys.
function getIDJson(flights) {
    let json = {};
    let id;

    for (let flight of flights) {
        id = flight.flight_id;
        if (id) {
            json[id] = 1;
        }
    }

    return json;
}

function removeOldFlights(idJson) {
    if (idJson) {
        for (let key of Object.keys(markers)) {
            if (!Object.prototype.hasOwnProperty.call(idJson, key)) {
                removeFlight(key);
            }
        }
    } else {
        for (let id of Object.keys(markers)) {
            removeFlight(id);
        }
    }
}
